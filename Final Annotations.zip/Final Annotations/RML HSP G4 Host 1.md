@prefix ns0: <https://w3id.org/biolink/vocab/> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .

<https://w3id.org/biolink/infores/knowledge-collaboratory>
  a <https://w3id.org/biolink/vocab/InformationResource> ;
  ns0:category "biolink:InformationResource"^^xsd:string ;
  ns0:id "infores:knowledge-collaboratory"^^xsd:string .

<https://www.frontiersin.org/articles/10.3389/fimmu.2022.947789/full#:~:text=HSPs%20inhibit%20viral%20infection%20by,viruses%20to%20silence%20their%20replication.>
  a ns0:Publication ;
  ns0:category "biolink:Publication"^^xsd:string ;
  ns0:id "https://www.frontiersin.org/articles/10.3389/fimmu.2022.947789/full#:~:text=HSPs%20inhibit%20viral%20infection%20by,viruses%20to%20silence%20their%20replication."^^xsd:string .

<http://identifiers.org/uniprot/P19120>
  a ns0:GeneProduct ;
  rdfs:label "HSC70"^^xsd:string ;
  ns0:category "biolink:GeneProduct"^^xsd:string ;
  ns0:id "UniProtKB:P19120"^^xsd:string .

<http://identifiers.org/umls/C0018850>
  a ns0:GeneProduct ;
  rdfs:label "Heat Shock Proteins"^^xsd:string ;
  ns0:category "biolink:GeneProduct"^^xsd:string ;
  ns0:id "UMLS:C0018850"^^xsd:string .

<http://identifiers.org/umls/C0887909>
  a ns0:GeneProduct ;
  rdfs:label "ncRNA"^^xsd:string ;
  ns0:category "biolink:GeneProduct"^^xsd:string ;
  ns0:id "UMLS:C0887909"^^xsd:string .

<http://purl.obolibrary.org/obo/NCBITaxon_11676>
  a ns0:OrganismTaxon ;
  rdfs:label "HIV-1"^^xsd:string ;
  ns0:category "biolink:OrganismTaxon"^^xsd:string ;
  ns0:id "NCBITaxon:11676"^^xsd:string .

<http://identifiers.org/umls/C0598312>
  a ns0:Disease ;
  rdfs:label "Replication"^^xsd:string ;
  ns0:category "biolink:Disease"^^xsd:string ;
  ns0:id "UMLS:C0598312"^^xsd:string .

<http://purl.obolibrary.org/obo/NCBITaxon_11646>
  a ns0:OrganismTaxon ;
  rdfs:label "Lentivirus"^^xsd:string ;
  ns0:category "biolink:OrganismTaxon"^^xsd:string ;
  ns0:id "NCBITaxon:11646"^^xsd:string .

<http://purl.obolibrary.org/obo/NCBITaxon_11632>
  a ns0:OrganismTaxon ;
  rdfs:label "Retroviridae"^^xsd:string ;
  ns0:category "biolink:OrganismTaxon"^^xsd:string ;
  ns0:id "NCBITaxon:11632"^^xsd:string .

<http://identifiers.org/uniprot/P21338>
  a ns0:ChemicalEntity ;
  rdfs:label "RNA"^^xsd:string ;
  ns0:category "biolink:ChemicalEntity"^^xsd:string ;
  ns0:id "UniProtKB:P21338"^^xsd:string .

<http://purl.obolibrary.org/obo/NCBITaxon_9606>
  a ns0:OrganismTaxon ;
  rdfs:label "human"^^xsd:string ;
  ns0:category "biolink:OrganismTaxon"^^xsd:string ;
  ns0:id "NCBITaxon:9606"^^xsd:string .

<http://identifiers.org/pubchem.compound/44135672>
  a ns0:ChemicalEntity ;
  rdfs:label "DNA"^^xsd:string ;
  ns0:category "biolink:ChemicalEntity"^^xsd:string ;
  ns0:id "PUBCHEM.COMPOUND:44135672"^^xsd:string .

<http://id.nlm.nih.gov/mesh/D012194>
  a ns0:GeneProduct ;
  rdfs:label "reverse transcriptase"^^xsd:string ;
  ns0:category "biolink:GeneProduct"^^xsd:string ;
  ns0:id "MESH:D012194"^^xsd:string .

<http://identifiers.org/umls/C1167396>
  a ns0:OrganismTaxon ;
  rdfs:label "host-cell nucleus"^^xsd:string ;
  ns0:category "biolink:OrganismTaxon"^^xsd:string ;
  ns0:id "UMLS:C1167396"^^xsd:string .

<http://purl.obolibrary.org/obo/CL_0000000>
  a ns0:OrganismTaxon ;
  rdfs:label "cell"^^xsd:string ;
  ns0:category "biolink:OrganismTaxon"^^xsd:string ;
  ns0:id "CL:0000000"^^xsd:string .

<http://identifiers.org/umls/C1819995>
  a ns0:OrganismTaxon ;
  rdfs:label "host cell"^^xsd:string ;
  ns0:category "biolink:OrganismTaxon"^^xsd:string ;
  ns0:id "UMLS:C1819995"^^xsd:string .

<http://identifiers.org/umls/C0850851>
  a ns0:Disease ;
  rdfs:label "infected human"^^xsd:string ;
  ns0:category "biolink:Disease"^^xsd:string ;
  ns0:id "UMLS:C0850851"^^xsd:string .

[]
  a ns0:Association ;
  rdf:object <http://identifiers.org/uniprot/P19120> ;
  rdf:predicate ns0:include ;
  rdf:subject <http://identifiers.org/umls/C0018850> ;
  ns0:aggregator_knowledge_source <https://w3id.org/biolink/infores/knowledge-collaboratory> ;
  ns0:category "biolink:Association"^^xsd:string ;
  ns0:id "collaboratory:UMLS:C0018850-biolink:include-UniProtKB:P19120"^^xsd:string ;
  ns0:publications <https://www.frontiersin.org/articles/10.3389/fimmu.2022.947789/full#:~:text=HSPs%20inhibit%20viral%20infection%20by,viruses%20to%20silence%20their%20replication.> .

[]
  a ns0:Association ;
  rdf:object <http://identifiers.org/umls/C0887909> ;
  rdf:predicate ns0:binds ;
  rdf:subject <http://njh.me/HSC79> ;
  ns0:aggregator_knowledge_source <https://w3id.org/biolink/infores/knowledge-collaboratory> ;
  ns0:category "biolink:Association"^^xsd:string ;
  ns0:id "collaboratory:undefined-biolink:binds-UMLS:C0887909"^^xsd:string ;
  ns0:publications <https://www.frontiersin.org/articles/10.3389/fimmu.2022.947789/full#:~:text=HSPs%20inhibit%20viral%20infection%20by,viruses%20to%20silence%20their%20replication.> .

[]
  a ns0:Association ;
  rdf:object <http://purl.obolibrary.org/obo/NCBITaxon_11676> ;
  rdf:predicate ns0:has_name ;
  rdf:subject <http://njh.me/HumanImmunodeficiencyVirus> ;
  ns0:aggregator_knowledge_source <https://w3id.org/biolink/infores/knowledge-collaboratory> ;
  ns0:category "biolink:Association"^^xsd:string ;
  ns0:id "collaboratory:undefined-biolink:has_name-NCBITaxon:11676"^^xsd:string ;
  ns0:publications <https://www.frontiersin.org/articles/10.3389/fimmu.2022.947789/full#:~:text=HSPs%20inhibit%20viral%20infection%20by,viruses%20to%20silence%20their%20replication.> .

[]
  a ns0:Association ;
  rdf:object <http://identifiers.org/umls/C0887909> ;
  rdf:predicate ns0:encodes ;
  rdf:subject <http://purl.obolibrary.org/obo/NCBITaxon_11676> ;
  ns0:aggregator_knowledge_source <https://w3id.org/biolink/infores/knowledge-collaboratory> ;
  ns0:category "biolink:Association"^^xsd:string ;
  ns0:id "collaboratory:NCBITaxon:11676-biolink:encodes-UMLS:C0887909"^^xsd:string ;
  ns0:publications <https://www.frontiersin.org/articles/10.3389/fimmu.2022.947789/full#:~:text=HSPs%20inhibit%20viral%20infection%20by,viruses%20to%20silence%20their%20replication.> .

[]
  a ns0:Association ;
  rdf:object <http://identifiers.org/umls/C0598312> ;
  rdf:predicate ns0:regulate ;
  rdf:subject <http://identifiers.org/umls/C0887909> ;
  ns0:aggregator_knowledge_source <https://w3id.org/biolink/infores/knowledge-collaboratory> ;
  ns0:category "biolink:Association"^^xsd:string ;
  ns0:id "collaboratory:UMLS:C0887909-biolink:regulate-UMLS:C0598312"^^xsd:string ;
  ns0:publications <https://www.frontiersin.org/articles/10.3389/fimmu.2022.947789/full#:~:text=HSPs%20inhibit%20viral%20infection%20by,viruses%20to%20silence%20their%20replication.> .

[]
  a ns0:Association ;
  rdf:object <http://purl.obolibrary.org/obo/NCBITaxon_11676> ;
  rdf:predicate ns0:manifests ;
  rdf:subject <http://identifiers.org/umls/C0598312> ;
  ns0:aggregator_knowledge_source <https://w3id.org/biolink/infores/knowledge-collaboratory> ;
  ns0:category "biolink:Association"^^xsd:string ;
  ns0:id "collaboratory:UMLS:C0598312-biolink:manifests-NCBITaxon:11676"^^xsd:string ;
  ns0:publications <https://www.frontiersin.org/articles/10.3389/fimmu.2022.947789/full#:~:text=HSPs%20inhibit%20viral%20infection%20by,viruses%20to%20silence%20their%20replication.> .

[]
  a ns0:Association ;
  rdf:object <http://purl.obolibrary.org/obo/NCBITaxon_11646> ;
  rdf:predicate ns0:has_genus ;
  rdf:subject <http://purl.obolibrary.org/obo/NCBITaxon_11676> ;
  ns0:aggregator_knowledge_source <https://w3id.org/biolink/infores/knowledge-collaboratory> ;
  ns0:category "biolink:Association"^^xsd:string ;
  ns0:id "collaboratory:NCBITaxon:11676-biolink:has_genus-NCBITaxon:11646"^^xsd:string ;
  ns0:publications <https://www.frontiersin.org/articles/10.3389/fimmu.2022.947789/full#:~:text=HSPs%20inhibit%20viral%20infection%20by,viruses%20to%20silence%20their%20replication.> .

[]
  a ns0:Association ;
  rdf:object <http://purl.obolibrary.org/obo/NCBITaxon_11632> ;
  rdf:predicate ns0:is_in ;
  rdf:subject <http://purl.obolibrary.org/obo/NCBITaxon_11646> ;
  ns0:aggregator_knowledge_source <https://w3id.org/biolink/infores/knowledge-collaboratory> ;
  ns0:category "biolink:Association"^^xsd:string ;
  ns0:id "collaboratory:NCBITaxon:11646-biolink:is_in-NCBITaxon:11632"^^xsd:string ;
  ns0:publications <https://www.frontiersin.org/articles/10.3389/fimmu.2022.947789/full#:~:text=HSPs%20inhibit%20viral%20infection%20by,viruses%20to%20silence%20their%20replication.> .

[]
  a ns0:Association ;
  rdf:object <http://purl.obolibrary.org/obo/NCBITaxon_11676> ;
  rdf:predicate ns0:are ;
  rdf:subject <http://purl.obolibrary.org/obo/NCBITaxon_11646> ;
  ns0:aggregator_knowledge_source <https://w3id.org/biolink/infores/knowledge-collaboratory> ;
  ns0:category "biolink:Association"^^xsd:string ;
  ns0:id "collaboratory:NCBITaxon:11646-biolink:are-NCBITaxon:11676"^^xsd:string ;
  ns0:publications <https://www.frontiersin.org/articles/10.3389/fimmu.2022.947789/full#:~:text=HSPs%20inhibit%20viral%20infection%20by,viruses%20to%20silence%20their%20replication.> .

[]
  a ns0:Association ;
  rdf:object <http://purl.obolibrary.org/obo/NCBITaxon_11632> ;
  rdf:predicate ns0:contains ;
  rdf:subject <http://purl.obolibrary.org/obo/NCBITaxon_11676> ;
  ns0:aggregator_knowledge_source <https://w3id.org/biolink/infores/knowledge-collaboratory> ;
  ns0:category "biolink:Association"^^xsd:string ;
  ns0:id "collaboratory:NCBITaxon:11676-biolink:contains-NCBITaxon:11632"^^xsd:string ;
  ns0:publications <https://www.frontiersin.org/articles/10.3389/fimmu.2022.947789/full#:~:text=HSPs%20inhibit%20viral%20infection%20by,viruses%20to%20silence%20their%20replication.> .

[]
  a ns0:Association ;
  rdf:object <http://purl.obolibrary.org/obo/NCBITaxon_11676> ;
  rdf:predicate ns0:becomes ;
  rdf:subject <http://identifiers.org/uniprot/P21338> ;
  ns0:aggregator_knowledge_source <https://w3id.org/biolink/infores/knowledge-collaboratory> ;
  ns0:category "biolink:Association"^^xsd:string ;
  ns0:id "collaboratory:UniProtKB:P21338-biolink:becomes-NCBITaxon:11676"^^xsd:string ;
  ns0:publications <https://www.frontiersin.org/articles/10.3389/fimmu.2022.947789/full#:~:text=HSPs%20inhibit%20viral%20infection%20by,viruses%20to%20silence%20their%20replication.> .
